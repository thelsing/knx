The folder contains the project files for TI Code Composer 10.
Just import this folder into your workspace.

* tested with TI Code Composer Version: 10.1.1.00004
* TI LaunchPadXL CC1310 with integrated XDS110 debug probe

Additional installation of an SDK is not required as the CC1310 SDK is already included as GIT subtree within this repository.
